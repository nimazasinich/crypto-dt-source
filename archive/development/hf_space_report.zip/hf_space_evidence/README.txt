HF Space Operational Report - Evidence Package
===============================================

این بسته شامل تمام artifacts و شواهد برای گزارش عملیاتی HuggingFace Space است.

محتویات / Contents:
--------------------
1. hf_space_operational_report.md - گزارش اصلی (فارسی + انگلیسی)
2. test_output.txt - خروجی کامل test harness
3. openapi_validation_report.txt - نتیجه validation OpenAPI spec
4. curl_examples.sh - اسکریپت curl قابل اجرا برای تست endpoints
5. metrics_summary.json - خلاصه metrics و آمار
6. README.txt - این فایل

Artifacts که نتوانستند generate شوند:
----------------------------------------
- server_logs_tail.txt: هیچ endpoint برای server logs وجود ندارد
- db_sample_dump/: هیچ DB access endpoint وجود ندارد  
- ws_session_capture.json: WebSocket connection با 403 رد شد
- postman_collection.json: می‌تواند از /docs export شود

استفاده / Usage:
-----------------
# اجرای تست‌های curl:
bash curl_examples.sh

# مشاهده گزارش:
cat hf_space_operational_report.md

# مشاهده metrics:
cat metrics_summary.json | python3 -m json.tool

وضعیت / Status:
----------------
Overall: PARTIAL (نیاز به اصلاحات کریتیکال)
Pass Rate: 6.25% (1/16 tests)
Critical Issues: 5
Estimated Effort: 6-8 هفته

برای جزئیات کامل، hf_space_operational_report.md را ببینید.
