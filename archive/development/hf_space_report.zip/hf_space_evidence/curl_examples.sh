#!/bin/bash
# Curl Examples for HF Space Testing

BASE_URL="https://really-amin-datasourceforcryptocurrency.hf.space"

echo "=== Testing HF Space Endpoints ==="
echo

echo "1. Health Check:"
curl -s "$BASE_URL/api/health" | python3 -m json.tool
echo

echo "2. System Status:"
curl -s "$BASE_URL/api/status" | python3 -m json.tool
echo

echo "3. Market Data:"
curl -s "$BASE_URL/api/market?limit=5" | python3 -m json.tool
echo

echo "4. Trading Pairs (MUST BE HF HTTP):"
curl -s "$BASE_URL/api/market/pairs?limit=10" | python3 -m json.tool
echo

echo "5. OHLC Data:"
curl -s "$BASE_URL/api/market/ohlc?symbol=BTC&interval=60&limit=5" | python3 -m json.tool
echo

echo "6. News:"
curl -s "$BASE_URL/api/news?limit=3" | python3 -m json.tool
echo

echo "7. Signals:"
curl -s "$BASE_URL/api/signals?limit=3" | python3 -m json.tool
echo

echo "8. Whale Transactions:"
curl -s "$BASE_URL/api/crypto/whales/transactions?limit=3" | python3 -m json.tool
echo

echo "9. Providers:"
curl -s "$BASE_URL/api/providers" | python3 -m json.tool | head -100
echo
